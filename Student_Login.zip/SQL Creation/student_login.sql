SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

CREATE SCHEMA IF NOT EXISTS `StudentLogin` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `StudentLogin` ;

-- -----------------------------------------------------
-- Table `StudentLogin`.`Professor`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `StudentLogin`.`Professor` ;

CREATE TABLE IF NOT EXISTS `StudentLogin`.`Professor` (
  `Pid` INT NOT NULL AUTO_INCREMENT,
  `Fname` VARCHAR(20) NOT NULL,
  `Lname` VARCHAR(20) NOT NULL,
  `Department` VARCHAR(5) NOT NULL,
  `Email` VARCHAR(40) NULL,
  PRIMARY KEY (`Pid`),
  UNIQUE INDEX `Pid_UNIQUE` (`Pid` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `StudentLogin`.`Student`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `StudentLogin`.`Student` ;

CREATE TABLE IF NOT EXISTS `StudentLogin`.`Student` (
  `Sid` INT NOT NULL AUTO_INCREMENT,
  `Fname` VARCHAR(20) NOT NULL,
  `Lname` VARCHAR(20) NOT NULL,
  `Major` VARCHAR(5) NULL,
  `Email` VARCHAR(40) NULL,
  `Username` VARCHAR(20) NOT NULL,
  `Password` VARCHAR(32) NOT NULL,
  PRIMARY KEY (`Sid`),
  UNIQUE INDEX `Sid_UNIQUE` (`Sid` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `StudentLogin`.`Class`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `StudentLogin`.`Class` ;

CREATE TABLE IF NOT EXISTS `StudentLogin`.`Class` (
  `Cid` INT NOT NULL,
  `Name` VARCHAR(50) NOT NULL,
  `Sectnum` INT NOT NULL,
  `Room` VARCHAR(10) NOT NULL,
  `Start_Time` TIME NOT NULL,
  `End_Time` TIME NOT NULL,
  `Pid` INT NOT NULL,
  PRIMARY KEY (`Cid`),
  UNIQUE INDEX `Cid_UNIQUE` (`Cid` ASC),
  INDEX `Class_To_Professor_idx` (`Pid` ASC),
  CONSTRAINT `Class_To_Professor`
    FOREIGN KEY (`Pid`)
    REFERENCES `StudentLogin`.`Professor` (`Pid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `StudentLogin`.`Login`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `StudentLogin`.`Login` ;

CREATE TABLE IF NOT EXISTS `StudentLogin`.`Login` (
  `Sid` INT NOT NULL,
  `Pid` INT NOT NULL,
  `Cid` INT NOT NULL,
  `Date` DATE NOT NULL,
  `Time` TIME NOT NULL,
  PRIMARY KEY (`Sid`, `Pid`, `Cid`, `Date`),
  INDEX `Login_to_Professor_idx` (`Pid` ASC),
  INDEX `Login_to_Class_idx` (`Cid` ASC),
  CONSTRAINT `Login_to_Student`
    FOREIGN KEY (`Sid`)
    REFERENCES `StudentLogin`.`Student` (`Sid`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `Login_to_Professor`
    FOREIGN KEY (`Pid`)
    REFERENCES `StudentLogin`.`Professor` (`Pid`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `Login_to_Class`
    FOREIGN KEY (`Cid`)
    REFERENCES `StudentLogin`.`Class` (`Cid`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
